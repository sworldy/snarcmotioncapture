///////////////////////////////////////////////////////////////////////////////
//
// LoadAnim.cpp 
//
// Purpose: implementation of the Biovision BVA Loaded
//
// Created:
//		JL 9/5/97		
//
// Todo:
//		I WILL PROBABLY PULL OUT THE CHANNELS INTO A NEW STRUCT
//		ADD SPEED OF PLAYBACK VARIABLE TO CHANNEL STRUCT
//
///////////////////////////////////////////////////////////////////////////////
//
//	Copyright 1997 Jeff Lander, All Rights Reserved.
//  For educational purposes only.
//  Please do not republish in electronic or print form without permission
//  Thanks - jeffl@darwin3d.com
//
///////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "LoadAnimation.h"
#include "LoadOBJ.h"
#include "EulerAngles.h"
#include "QuatTypes.h"
#include <math.h>;


#include <cstring>
#include <fstream>
using namespace std;
int number = 5;
HANDLE PipeHandle[17];
char* PipeName[] = {"\\\\.\\Pipe\\sensor0","\\\\.\\Pipe\\sensor1","\\\\.\\Pipe\\sensor2","\\\\.\\Pipe\\sensor3",
"\\\\.\\Pipe\\sensor4","\\\\.\\Pipe\\sensor5","\\\\.\\Pipe\\sensor6","\\\\.\\Pipe\\sensor7",
"\\\\.\\Pipe\\sensor8","\\\\.\\Pipe\\sensor9","\\\\.\\Pipe\\sensor10","\\\\.\\Pipe\\sensor11",
"\\\\.\\Pipe\\sensor12","\\\\.\\Pipe\\sensor13","\\\\.\\Pipe\\sensor14","\\\\.\\Pipe\\sensor15",
"\\\\.\\Pipe\\sensor16"};

///////////////////////////////////////////////////////////////////////////////
// Function:	ParseString
// Purpose:		Actually breaks a string of words into individual pieces
// Arguments:	Source string in, array to put the words and the count


//////////////////////////////////////////////////////////
////////////�򿪹ܵ�//////////////////////////////////////
BOOL LoadAnimationTest(int n,t_Bone *m_SelectedBone,t_Bone *rootBone,int *anima)
{ 
	*anima = 1;
	for( int i=0; i<16; ++i)
	{
		if (WaitNamedPipe(PipeName[i], NMPWAIT_WAIT_FOREVER) == 0)
		{
			CString error;
			error.Format("Pipe %d connecting failed\n",i);
			AfxMessageBox(error);
			//		return;
		}
	}
	if (WaitNamedPipe(PipeName[16], NMPWAIT_WAIT_FOREVER) == 0)
		{
			CString error;
			error.Format("Pipe %d connecting failed\n",16);
			AfxMessageBox(error);
			//		return;
		}
	for(int  i=0; i<16; ++i)
	{
		if ((PipeHandle[i] = CreateFile(PipeName[i],GENERIC_READ,
			0,(LPSECURITY_ATTRIBUTES) NULL, OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,(HANDLE) NULL)) == INVALID_HANDLE_VALUE)
		{
			CString error;
			error.Format("Pipe %d failed with error %d\n", i,GetLastError());
			AfxMessageBox(error);
			//		return;
		}
		Sleep(1500);
	}
	if ((PipeHandle[16] = CreateFile(PipeName[16],GENERIC_READ,
			0,(LPSECURITY_ATTRIBUTES) NULL, OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,(HANDLE) NULL)) == INVALID_HANDLE_VALUE)
		{
			CString error;
			error.Format("Pipe %d failed with error %d\n", 16,GetLastError());
			AfxMessageBox(error);
			//		return;
		}
	AfxMessageBox("All the pipes has been connected!");
	return 0;
}


ofstream file = ofstream("1.txt");
//��ȡ���ڵ�����///////////////////////////////////////////////
void BoneAdvanceFrameTest0(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[56];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
				bone->axisangle.x = -p[6]*10;
			    bone->axisangle.y = -p[4]*10;
		     	bone->axisangle.z = p[5]*10;
			    //bone->axisangle.theta = p[3];
                //bone->axisangle.ax = p[2];
			    //bone->axisangle.ay = p[0];
			    //bone->axisangle.az = p[1];
				//bone->trans.a = 0;
				//bone->trans.c = 0;
				//bone->trans.d = 0;
				bone->axisangle.theta = 0;
				bone->axisangle.ax = 0;
				bone->axisangle.ay = 0;
				bone->axisangle.az = 0;
              // file << p[4] << "\t"<< p[5] << "\t"<< p[6] << "\t"<< bone->axisangle.ax << "\t"<< bone->axisangle.ay << "\t"<< bone->axisangle.az <<"\n";
			}
		}
}

//��ȡ����1����///////////////////////////////////////////////
void BoneAdvanceFrameTest1(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[0];
			    bone->axisangle.ax = p[1];
			    bone->axisangle.ay = -p[3];
			    bone->axisangle.az = p[2];
				/*bone->axisangle.theta = 0;
			    bone->axisangle.ax = -0;
			    bone->axisangle.ay = 0;
			    bone->axisangle.az = 0;*/

			}
		}
}

//��ȡ����2����///////////////////////////////////////////////
void BoneAdvanceFrameTest2(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[0];
			    bone->axisangle.ax = p[1];
			    bone->axisangle.ay = -p[3];
			    bone->axisangle.az = p[2];
				/*bone->axisangle.theta = 0;
			    bone->axisangle.ax = -0;
			    bone->axisangle.ay = 0;
			    bone->axisangle.az = 0;*/

			}
		}
}

//��ȡ����3����///////////////////////////////////////////////
void BoneAdvanceFrameTest3(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[0];
			    bone->axisangle.ax = p[1];
			    bone->axisangle.ay = -p[3];
			    bone->axisangle.az = p[2];
				/*bone->axisangle.theta = 0;
			    bone->axisangle.ax = -0;
			    bone->axisangle.ay = 0;
			    bone->axisangle.az = 0;*/

			}
		}
}

//��ȡ�������///////////////////////////////////////////////
void BoneAdvanceFrameTest4(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[0];
			    bone->axisangle.ax = p[1];
			    bone->axisangle.ay = p[2];
			    bone->axisangle.az = p[3];

			}
		}
}

//��ȡ����ؽ�����///////////////////////////////////////////////
void BoneAdvanceFrameTest5(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[0];
			    bone->axisangle.ax = p[1];
			    bone->axisangle.ay = p[2];
			    bone->axisangle.az = p[3];

			}
		}
}

//��ȡ��������///////////////////////////////////////////////
void BoneAdvanceFrameTest6(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[0];
			    bone->axisangle.ax = p[1];
			    bone->axisangle.ay = p[2];
			    bone->axisangle.az = p[3];
				/*bone->axisangle.theta = 0;
			    bone->axisangle.ax = 0;
			    bone->axisangle.ay = 0;
			    bone->axisangle.az = 0;*/

			}
		}
}

//��ȡ�Ҽ�����///////////////////////////////////////////////
void BoneAdvanceFrameTest7(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[0];
			    bone->axisangle.ax = p[1];
			    bone->axisangle.ay = -p[2];
			    bone->axisangle.az = -p[3];

			}
		}
}

//��ȡ����ؽ�����///////////////////////////////////////////////
void BoneAdvanceFrameTest8(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[0];
			    bone->axisangle.ax = p[1];
			    bone->axisangle.ay = -p[2];
			    bone->axisangle.az = -p[3];

			}
		}
}

//��ȡ��������///////////////////////////////////////////////
void BoneAdvanceFrameTest9(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[0];
			    bone->axisangle.ax = p[1];
			    bone->axisangle.ay = -p[2];
			    bone->axisangle.az = -p[3];
				/*bone->axisangle.theta = 0;
			    bone->axisangle.ax = 0;
			    bone->axisangle.ay = 0;
			    bone->axisangle.az = 0;*/

			}
		}
}
//��ȡͷ����///////////////////////////////////////////////
void BoneAdvanceFrameTest10(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[0];
			    bone->axisangle.ax = p[3];
			    bone->axisangle.ay = p[1];
			    bone->axisangle.az = p[2];
				/*bone->axisangle.theta = 0;
			    bone->axisangle.ax = 0;
			    bone->axisangle.ay = 0;
			    bone->axisangle.az = 0;*/

			}
		}
}
//��ȡ���������///////////////////////////////////////////////
void BoneAdvanceFrameTest11(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[3];
			    bone->axisangle.ax = -p[0];
			    bone->axisangle.ay = -p[1];
			    bone->axisangle.az = p[2];

			}
		}
}
//��ȡ��С������///////////////////////////////////////////////
void BoneAdvanceFrameTest12(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[3];
			    bone->axisangle.ax = -p[0];
			    bone->axisangle.ay = -p[1];
			    bone->axisangle.az = p[2];

			}
		}
}
//��ȡ�������///////////////////////////////////////////////
void BoneAdvanceFrameTest13(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[3];
			    bone->axisangle.ax = -p[0];
			    bone->axisangle.ay = -p[2];
			    bone->axisangle.az = -p[1];
				/*bone->axisangle.theta = 0;
			    bone->axisangle.ax = 0;
			    bone->axisangle.ay = 0;
			    bone->axisangle.az = 0;*/

			}
		}
}
//��ȡ�Ҵ�������///////////////////////////////////////////////
void BoneAdvanceFrameTest14(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[3];
			    bone->axisangle.ax = p[0];
			    bone->axisangle.ay = -p[1];
			    bone->axisangle.az = -p[2];

			}
		}
}
//��ȡ��С������///////////////////////////////////////////////
void BoneAdvanceFrameTest15(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[3];
			    bone->axisangle.ax = p[0];
			    bone->axisangle.ay = -p[1];
			    bone->axisangle.az = -p[2];

			}
		}
}
//��ȡ�ҽ�����///////////////////////////////////////////////
void BoneAdvanceFrameTest16(t_Bone *bone,int num,BOOL doChildren)
{   
	char buffer[32];
	CString temp;
	unsigned long BytesRead;
	double *p;
	for(int i=0;i<number;++i)
		{
			if (ReadFile(PipeHandle[num], buffer, sizeof(buffer), &BytesRead,  NULL) <= 0)
			{
				CString error;
				error.Format("Read pipe%d failed with error %d\n", num, GetLastError());
				AfxMessageBox(error);
			}
			p = reinterpret_cast<double*>(buffer);
			if((i%number) == 0)
			{
                bone->axisangle.theta = p[3];
			    bone->axisangle.ax = -p[0];
			    bone->axisangle.ay = -p[2];
			    bone->axisangle.az = -p[1];
				/*bone->axisangle.the-ta = 0;
			    bone->axisangle.ax = 0;
			    bone->axisangle.ay = 0;
			    bone->axisangle.az = 0;*/

			}
		}
}
